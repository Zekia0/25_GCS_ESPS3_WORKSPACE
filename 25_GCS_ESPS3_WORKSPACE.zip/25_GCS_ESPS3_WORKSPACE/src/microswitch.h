#ifndef __MICRO_SWITCH_H
#define __MICRO_SWITCH_H

bool trigger_switch(void);
void trigger_init(void);

#endif