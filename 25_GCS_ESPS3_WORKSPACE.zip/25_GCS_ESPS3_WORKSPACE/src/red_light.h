#ifndef __RED_LIGHT_H__
#define __RED_LIGHT_H__

void red_light_init(void);
void full_warning(void);

#endif //__RED_LIGHT_H__