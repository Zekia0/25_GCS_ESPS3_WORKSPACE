#ifndef __SERIAL_SCREEN_H__
#define __SERIAL_SCREEN_H__

void screen_init(void);
void screen_num_change(int class_ID);
void stop_video(void);
void screen_main_info_update(int cl);
void screen_fresh(int cl);

#endif //__SERIAL_SCREEN_H__